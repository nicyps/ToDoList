This is a basic personal project to just practice using JavaScript. 

If by any chance you opened this, I wanted to mention that the only cool thing is that it saves the tasks in the browser's Local Storage so when the page reloads the tasks will be "saved", if you want something really light to write down everyday tasks day, it's really worth trying to do it too, I did it on a holiday afternoon, I liked the result even though it was just so I wouldn't miss out on practice.

Thanks for reading! Now, if you really want to see it working, I highly recommend you download the .zip file, as it contains all the images I used. I just made the files available like this, separately, because I think it looks better for viewing, well I'm still learning lol